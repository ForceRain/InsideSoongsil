
public interface Sequence {
	int next();
}
